const body = document.getElementsByTagName("body")[0]// since we want the body it will be a tag element. Index 0 so it can start from green
function setColor(name) {
  body.style.backgroundColor = name;
}

function randomColor() {
  const darkRed = Math.round(Math.random() * 255)
  const salmon = Math.round(Math.random() * 255)
  const cadetBlue = Math.round(Math.random() * 255)
  const color = `rgb(${darkRed}, ${salmon}, ${cadetBlue})`
  body.style.backgroundColor = color;
}
randomColor()